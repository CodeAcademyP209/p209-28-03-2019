﻿using Microsoft.AspNetCore.Identity;
using Microsoft.Extensions.Configuration;
using P209_Identity.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace P209_Identity.Data
{
    public static class DbInitializor
    {
        public async static Task Seed(IdentityContext context, 
                                UserManager<ApplicationUser> userManager, 
                                RoleManager<IdentityRole> roleManager,
                                IConfiguration configuration)
        {
            await context.Database.EnsureCreatedAsync();

            if(!await roleManager.RoleExistsAsync(SD.AdminRole))
            {
                await roleManager.CreateAsync(new IdentityRole(SD.AdminRole));
            }

            if (!await roleManager.RoleExistsAsync(SD.MemberRole))
            {
                await roleManager.CreateAsync(new IdentityRole(SD.MemberRole));
            }

            if (!await roleManager.RoleExistsAsync(SD.ModeratorRole))
            {
                await roleManager.CreateAsync(new IdentityRole(SD.ModeratorRole));
            }

            if (await userManager.FindByEmailAsync("elieliyev@gmail.com") == null)
            {
                var admin = new ApplicationUser
                {
                    Email = "elieliyev@gmail.com",
                    UserName = "elieliyev@gmail.com",
                    Firstname = "Eli",
                    Lastname = "Eliyev"
                };

                var result = await userManager.CreateAsync(admin, configuration["AdminSettings:Password"]);

                if (result.Succeeded)
                {
                    await userManager.AddToRoleAsync(admin, SD.AdminRole);
                }
            }
        }
    }
}
