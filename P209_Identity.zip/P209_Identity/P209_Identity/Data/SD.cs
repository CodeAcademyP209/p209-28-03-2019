﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace P209_Identity.Data
{
    public static class SD
    {
        public const string AdminRole = "Admin";
        public const string MemberRole = "Member";
        public const string ModeratorRole = "Moderator";
    }
}
